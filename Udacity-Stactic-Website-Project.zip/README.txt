Project:
	Deploy Static Website on AWS

Website URLs
CloudFront Domain Name : https://d33n5axjv6d1v7.cloudfront.net/

Website End Point : http://my-369627679315-bucket.s3-website-us-east-1.amazonaws.com/

S3 Object URL : https://my-369627679315-bucket.s3.amazonaws.com/index.html

Note: The background image was gotten from the website https://www.pexels.com/search/travel/ 
The owner of the image is Asad Photos Maldives and this is the link to their page https://www.pexels.com/@asadphotography/
Thanks 
